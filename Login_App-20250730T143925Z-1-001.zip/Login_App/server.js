const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// GET home page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'home.html'));
});

// GET login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// POST login data
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  res.send(`<!DOCTYPE html>
    <html>
    <head>
      <title>Login Data</title>
      <style>
        body {
          background: linear-gradient(135deg, #89f7fe, #66a6ff);
          font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          margin: 0;
        }

        .output-box {
          background: rgba(255, 255, 255, 0.25);
          backdrop-filter: blur(10px);
          padding: 30px;
          border-radius: 15px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
          text-align: center;
          color: #333;
        }

        h2 {
          margin-bottom: 20px;
          color: #002b71;
        }

        p {
          font-size: 18px;
          margin: 10px 0;
        }
      </style>
    </head>
    <body>
      <div class="output-box">
        <h2>Login Successful!</h2>
        <p><strong>Username:</strong> ${username}</p>
        <p><strong>Password:</strong> ${password}</p>
      </div>
    </body>
    </html>`);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
